<template>
  <div class="page-container">
    <van-nav-bar title="帖子详情" left-arrow @click-left="$router.back()" />

    <div v-if="post" class="detail-card">
      <h2>{{ post.title }}</h2>
      <div class="detail-meta">
        <span>{{ post.authorName }}</span>
        <span>· {{ formatTime(post.createTime) }}</span>
        <span>· {{ post.viewCount }} 阅读</span>
        <van-tag v-if="post.board" type="primary" size="small" style="margin-left:8px">{{ boardMap[post.board] }}</van-tag>
      </div>
      <!-- 帖子图片 -->
      <div v-if="postImages.length > 0" class="post-images">
        <img v-for="(url, i) in postImages" :key="i" :src="url" class="post-img" @click="previewImg = url" />
      </div>
      <div class="detail-content" v-html="post.content"></div>

      <div class="action-bar">
        <div class="action-item" @click="handleLike">
          <van-icon :name="liked ? 'like' : 'like-o'" :color="liked ? '#ee0a24' : ''" />
          <span>{{ post.likeCount }}</span>
        </div>
        <div class="action-item" @click="handleFav">
          <van-icon :name="favorited ? 'star' : 'star-o'" :color="favorited ? '#ff976a' : ''" />
          <span>收藏</span>
        </div>
        <div class="action-item" @click="showComment = true">
          <van-icon name="comment-o" />
          <span>回复 {{ post.commentCount }}</span>
        </div>
        <div v-if="isOwner" class="action-item" @click="handleDelete">
          <van-icon name="delete-o" color="#ee0a24" />
          <span style="color:#ee0a24">删除</span>
        </div>
      </div>
    </div>

    <!-- 回复列表（楼层） -->
    <div class="comment-section">
      <div class="section-title">全部回复 ({{ comments.length }})</div>
      <div v-for="(c, idx) in comments" :key="c.id" class="comment-item">
        <div class="comment-header">
          <span class="comment-floor">#{{ idx + 1 }}</span>
          <span class="comment-author">{{ c.authorName }}</span>
          <span class="comment-time">{{ formatTime(c.createTime) }}</span>
        </div>
        <div class="comment-content">{{ c.content }}</div>
      </div>
      <van-empty v-if="!loading && comments.length === 0" description="暂无回复，快来抢沙发" />
    </div>

    <!-- 图片预览 -->
    <div v-if="previewImg" class="img-preview" @click="previewImg = null">
      <img :src="previewImg" alt="" />
    </div>

    <van-dialog v-model:show="showComment" title="发表回复" show-cancel-button @confirm="handleComment">
      <van-field v-model="commentText" type="textarea" rows="3" placeholder="写下你的回复..." />
    </van-dialog>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { getPostDetail, toggleLike, toggleFavorite, isLiked, isFavorited, getComments, createComment, deletePost } from '../api/post'
import { useUserStore } from '../stores/user'
import { showConfirmDialog, showToast } from 'vant'

const route = useRoute()
const router = useRouter()
const userStore = useUserStore()
const post = ref(null)
const comments = ref([])
const liked = ref(false)
const favorited = ref(false)
const showComment = ref(false)
const commentText = ref('')
const loading = ref(false)
const previewImg = ref(null)

const postImages = computed(() => {
  try {
    const imgs = post.value?.images
    if (!imgs) return []
    const parsed = typeof imgs === 'string' ? JSON.parse(imgs) : imgs
    return Array.isArray(parsed) ? parsed : []
  } catch { return [] }
})

const isOwner = computed(() => {
  return userStore.userInfo?.userId && post.value?.authorId &&
    userStore.userInfo.userId === post.value.authorId
})

const boardMap = { study: '学习', job: '求职', life: '生活', tech: '技术', other: '闲聊' }

function formatTime(t) {
  if (!t) return ''
  const d = new Date(t)
  return d.toLocaleDateString('zh-CN') + ' ' + d.toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' })
}

async function handleLike() {
  if (!userStore.isLoggedIn()) return router.push('/login')
  try {
    const res = await toggleLike(post.value.id)
    liked.value = !liked.value
    post.value.likeCount = res.data
  } catch {}
}

async function handleFav() {
  if (!userStore.isLoggedIn()) return router.push('/login')
  try {
    const res = await toggleFavorite(post.value.id)
    favorited.value = res.data
  } catch {}
}

async function handleComment() {
  if (!commentText.value.trim()) return
  try {
    await createComment({ postId: post.value.id, content: commentText.value })
    commentText.value = ''
    showComment.value = false
    fetchComments()
  } catch {}
}

async function handleDelete() {
  await showConfirmDialog({ title: '确认删除', message: '删除后不可恢复' })
  try {
    await deletePost(post.value.id)
    showToast('已删除')
    setTimeout(() => router.back(), 800)
  } catch {}
}

async function fetchComments() {
  loading.value = true
  try {
    const res = await getComments(post.value.id)
    comments.value = res.data || []
    if (post.value) post.value.commentCount = comments.value.length
  } catch {} finally { loading.value = false }
}

onMounted(async () => {
  const id = route.params.id
  try {
    const [detailRes] = await Promise.all([
      getPostDetail(id),
      (async () => {
        if (userStore.isLoggedIn()) {
          const [l, f] = await Promise.all([isLiked(id), isFavorited(id)])
          liked.value = l.data
          favorited.value = f.data
        }
      })()
    ])
    post.value = detailRes.data
  } catch {}
  fetchComments()
})
</script>

<style scoped>
.detail-card { background: #fff; padding: 16px; margin-bottom: 8px; }
.detail-card h2 { font-size: 20px; line-height: 1.4; margin-bottom: 10px; }
.detail-meta { font-size: 12px; color: #999; margin-bottom: 16px; display: flex; align-items: center; flex-wrap: wrap; gap: 4px; }
.detail-content { font-size: 15px; line-height: 1.8; }
.detail-content :deep(img) { max-width: 100%; }
.action-bar { display: flex; justify-content: space-around; padding: 14px 0; margin-top: 16px; border-top: 1px solid #f0f0f0; }
.action-item { display: flex; flex-direction: column; align-items: center; gap: 4px; font-size: 12px; color: #999; cursor: pointer; }
.action-item :deep(.van-icon) { font-size: 22px; }
.comment-section { background: #fff; padding: 16px; }
.section-title { font-size: 15px; font-weight: 600; margin-bottom: 12px; }
.comment-item { padding: 12px 0; border-bottom: 1px solid #f5f5f5; }
.comment-header { display: flex; align-items: center; gap: 8px; margin-bottom: 6px; }
.comment-floor { font-size: 11px; color: #1989fa; font-weight: 600; }
.comment-author { font-size: 13px; font-weight: 500; }
.comment-time { font-size: 11px; color: #999; margin-left: auto; }
.comment-content { font-size: 14px; color: #555; line-height: 1.6; }
.post-images { display: flex; flex-wrap: wrap; gap: 8px; margin: 12px 0; }
.post-img { width: 100px; height: 100px; object-fit: cover; border-radius: 6px; cursor: pointer; }
.img-preview { position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.9); z-index: 9999; display: flex; align-items: center; justify-content: center; }
.img-preview img { max-width: 100%; max-height: 100%; object-fit: contain; }
</style>
